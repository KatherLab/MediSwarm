#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
python3 -m nvflare.fuel.hci.tools.admin -m $DIR/.. -s fed_admin.json
