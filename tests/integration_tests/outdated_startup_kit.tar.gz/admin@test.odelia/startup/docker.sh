#!/usr/bin/env bash

while [[ "$#" -gt 0 ]]; do
    case $1 in
       --no_pull)         NOPULL="1";;
        *) echo "Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
# To use host network
NETARG="--net=host"

DOCKER_IMAGE=localhost:5000/odelia:1.0.1-dev.251023.e940002
if [ -z "$NOPULL" ]; then
    echo "Updating docker image"
    docker pull $DOCKER_IMAGE
fi
CONTAINER_NAME=odelia_swarm_admin_e940002

echo "Starting docker with $DOCKER_IMAGE as $CONTAINER_NAME"
docker run --rm -it --name=$CONTAINER_NAME -v $DIR/../local/:/fl_admin/local/ -v $DIR/../startup/:/fl_admin/startup/ -w /fl_admin/startup/ $NETARG $DOCKER_IMAGE /bin/bash -c "./fl_admin.sh"
