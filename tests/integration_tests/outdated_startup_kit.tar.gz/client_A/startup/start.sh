#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
all_arguments="${@}"
doCloud=false
# parse arguments
while [[ $# -gt 0 ]]
do
    key="$1"
    case $key in
      --cloud)
        doCloud=true
        shift
      ;;
    esac
    shift
done

if [ $doCloud = true ]
then
  echo "Only on-prem is currently supported."
else
  $DIR/sub_start.sh &
fi
